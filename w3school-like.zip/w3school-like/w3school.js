const scrollButton = document.getElementById('scrollButton')
const pop = document.getElementById('pop')
const closeButton = document.getElementById('closeButton')

scrollButton.addEventListener("click", () => {
    window.scrollTo(0, 0)
})

closeButton.addEventListener("click", () => {
    pop.style.opacity='0'
    pop.style.pointerEvents='none'
})

function load() {
    setTimeout(() => {
        pop.style.opacity='1'
        pop.style.pointerEvents='painted'
    }, 300);
}

load()