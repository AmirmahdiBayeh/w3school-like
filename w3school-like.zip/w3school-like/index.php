<!DOCTYPE html>
<?php
$cookie_name = "user";
$cookie_value = "EA_Fan";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); 
echo "Cookie '" . $cookie_name . "' is set!<br>";

if(isset($_COOKIE[$cookie_name])) {
    // echo "Value is: " . $_COOKIE[$cookie_name];
} else {
    // echo "Cookie named '" . $cookie_name . "' is not set!";
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>W3Schools Online Web Tutorials</title>
    <script src="https://kit.fontawesome.com/2dec4d93bf.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="w3school.css">
    <style>
        body{
            margin: 0;
        }
    </style>
</head>
<body>
    <b>
    <div id="head">
        <a class="img" href="#"><img src="imW3Schools_logo.svg_2.png" alt=""></a>
        <a class="tut" href="#" style="width: 116px ;">Tutorials</a>
        <a class="ref" href="#" style="width:132px ;">References</a> 
        <a class="exe" href="#" style="width:118px ;">Exercises</a>
        <a class="video" href="#">video</a>
        <a class="log" href="login.html">Log in</a>
        <a class="website" href="singup.html">sing up</a>
        <a class="darkmode" href="" style="top:5px"><i class="fa-solid fa-circle-half-stroke"></i></a>
        <a class="world" href=""><i class="fa-solid fa-earth-americas"></i></a>
        <a class="searchbox" href=""><i class="fa-solid fa-magnifying-glass"></i></a>
    </b>
    </div>
    
    <div class="background">
        <h1 class="learn">
            Learn to code
        </h1>
        <h3 class="with">with the world's largest web developer site.
        </h3>
        <br>
        
            <input type="text" placeholder="Search our tutorials, e.g. HTML" class="search2" style=" position: relative; left: 40px;   border-radius: 25px; font: inherit; border: none; margin: 10px; width: 40%; height: 38px; padding: 10px; border: 1px solid #282A35;">
            <a class="searchbox2" href=""><i class="fa-solid fa-magnifying-glass"></i></a>
        <h4><a class="begin" href="#">not sure Where To Begin?</a></h4>    
    </div>
    <div class="background2"><b>
        <img class="i123" src="Screenshot 2022-08-12 044739.png" alt=""  width="600px" >
        <div class="html3"><h1 style="color: black; font-size:100px;font-weight:700;margin-top:-40px; ">HTML</h1>
            <p style=" margin-top: 60px; color: black; font-size:19px;">The language for building web pages</p>
            <a class="learnhtml" href="#">Learn HTML</a>      <a class="video-tutotial" href="#" >Video Tutorial</a>
            <a class="html-ref" href="#" >HTML Reference</a>
            <a class="buy" href="#" >Buy Certificate</a>
        
        
        </b></div></div>

        <div class="background3"><b>
            <img class="i123" src="Screenshot 2022-08-12 085604.png" alt=""  width="600px" >
            <div class="html3"><h1 style="color: black; font-size:100px;font-weight:700;margin-top:-40px; ">CSS</h1>
                <p style=" margin-top: 60px; color: black; font-size:19px;">The language for styling web pages</p>
                <a class="learnhtml" href="#">Learn CSS</a>
                <a class="CSS-ref" href="#" >CSS Reference</a>
                <a class="buy2" href="#" >Buy Certificate</a>
            
            
            </b>  </div></div>

            <script src="./w3school.js"></script>
    <script>
        function toggleDarkmode()
        {
            var body = document.querySelector('body');
            body.classList.toggle('dark-mode');
        }
    </script>
    
</body>
</html>