<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "w3";

$conn = mysqli_connect($servername, $username, $password, $db);

// $sql = "CREATE DATABASE W3;";
// $sql = "CREATE TABLE Users(
//    id int (6) AUTO_INCREMENT PRIMARY KEY ,
//    email VARCHAR(60),
//    pass  VARCHAR(60),
//    firstname VARCHAR(60),
//    lastname VARCHAR(60));";

$mail = $_POST['email'];
$passs = $_POST['pass'];
$fn = $_POST['firstname'];
$ln = $_POST['lastname'];


$sqlv = "INSERT INTO Users (email,pass,firstname,lastname ) VALUES ('$mail','$passs','$fn','$ln')";

mysqli_query($conn,$sqlv);



// mysqli_query($conn,$sql);